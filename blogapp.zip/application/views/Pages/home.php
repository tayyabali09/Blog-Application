
<div class="container">
	<div class="jumbotron">
		
		<h2>Hello,Wellcome to Blog Website.</h2>
		<h3>I hope you like our website :)</h3>
	</div>

</div>
